# Facebook Cloaker
FaceCloaker is a best way to cloak your blackhat traffic for Facebook, avoid all of the Facebook verifications !

Subscribe on https://www.facecloaker.com

Thanks to [tcdent](https://github.com/tcdent/php-restclient) for the PHP REST Client Class.
