## Introduction
FBBOT is library to do some `hack` to facebook

You can use it to login with your email and password on facebook account (which
facebook never let you do it)

When you login, you can get an access token with full permissions (yeah, I mean
you can have right to do anything with your account). So let thinking about some
your facebook bot like auto comment, auto like, auto post to your friends wall,
auto add friends, ....

# Usage
Please take a look at test_facebook.py


That 's too many words. Let 's start code :)
